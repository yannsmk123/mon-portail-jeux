@echo off
cd /d "%~dp0"
echo ====================================================
echo     MARVEL FUSION - MODE 2 JOUEURS RESEAU LOCAL
echo ====================================================
where node >nul 2>&1
if errorlevel 1 (
  echo ERREUR: Node.js introuvable. Installez Node.js LTS depuis nodejs.org
  pause
  exit /b 1
)
echo.
echo NE FERMEZ PAS CETTE FENETRE PENDANT LA PARTIE.
echo Les adresses a utiliser sur le PC 2 vont s'afficher :
echo.
node server.js
if errorlevel 1 echo Le serveur s'est arrete avec une erreur.
pause
