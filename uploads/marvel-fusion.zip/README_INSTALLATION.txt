MARVEL FUSION - ACCUEIL UNIQUE / SOLO + DEUX JOUEURS EN RESEAU LOCAL
Version d'intégration et de diagnostic - 30 octobre 2026

1. IMPORTANT : UN SEUL HTML
Le fichier index.html contient l'intégralité du jeu solo et l'interface du mode deux joueurs.
Au démarrage, choisis « Mode solo » ou « Mode 2 joueurs ». Un seul moteur est chargé à
la fois pour éviter que l'IA du solo continue à jouer pendant un duel réseau.
Le serveur reste indispensable pour deux PC. NE lance PAS index.html par double-clic
pour le multijoueur : il faut passer par Node.js.

2. INSTALLATION - PC 1 (HOTE)
- Installer Node.js LTS (https://nodejs.org), version >=20.
- Extraire tout le dossier ZIP.
- Double-cliquer sur LANCER_WINDOWS.bat dans le dossier.
- Garder la fenêtre noire du serveur ouverte.
- Dans Chrome/Edge, ouvrir http://localhost:3000
- Choisir « 2 joueurs », saisir son nom puis « Créer une salle ».

3. INSTALLATION - PC 2
- Être sur le même Wi-Fi / réseau Ethernet que le PC 1.
- Sur le PC 1, repérer l'adresse indiquée par le serveur, par exemple 192.168.1.25.
- Sur le PC 2 : http://192.168.1.25:3000 (IP REELLE du PC 1, HTTP sans S).
- Si la page ne s'ouvre pas, tester http://192.168.1.25:3000/health .
- Autoriser Node.js sur les réseaux PRIVES dans le pare-feu Windows du PC 1.
- Choisir « 2 joueurs », entrer le code de salle, cliquer « Rejoindre ».
- La partie est synchronisée par le serveur Node.js ; les cartes adverses sont cachées.

4. POUR RETROUVER VOS MUSIQUES, SONS, IMAGES ET VIDEOS
IMPORTANT : l'ancien JSON « Sauvegarde complète » du solo N'INCLUAIT PAS les MP3,
les bruitages, les animations des pouvoirs et les médias de victoire/défaite. Il
contenait seulement la partie, les paramètres et les images de cartes de l'atelier.
Il est donc techniquement impossible de reconstituer vos MP3 uniquement depuis ce JSON.

Pour migrer les médias QUI SONT ENCORE DANS CE NAVIGATEUR, sur le PC concerné :
A. Ouvrir le nouveau site dans le navigateur qui stocke les médias d'origine.
B. Cliquer « ↓ Pack médias » (barre en haut), puis enregistrer le JSON proposé.
C. Sur chaque PC, ouvrir le même site et cliquer « ↑ Importer pack ».
D. Sélectionner ce NOUVEAU fichier « MARVEL_FUSION_Pack_Medias_...json ».
E. Revenir au mode choisi ou l'actualiser. Tester la musique avec ▶ en haut à droite
   du mode réseau. Les navigateurs exigent souvent un clic pour démarrer un MP3.

LIMITATION : les médias sauvegardés à l'origine par une page file:// ou par
http://localhost sur une autre machine sont dans une autre « origine » navigateur.
Le nouveau site ne peut pas les lire automatiquement. S'il n'est pas possible de
les exporter depuis la même origine, il faut REIMPORTER les fichiers MP3, WAV, vidéos
et GIF manuellement sur le nouveau site. Les fichiers sont stockés localement, pas
synchronisés en direct entre les deux ordinateurs.

Le nouvel importateur accepte également les anciens JSON « Mes cartes » et «
Sauvegarde complète » pour récupérer les illustrations et les préférences, MAIS
NE PEUT PAS inventer les MP3 absents de ces sauvegardes.

5. ANIMATIONS ET CONTROLES EN RESEAU
- La main peut être glissée sur son terrain, sur un carré/suite et sur le terrain
  adverse selon les règles. Les gestes souris, tactile et stylet sont pris en charge.
- Les animations « main -> terrain » et « terrain -> défausse », sons de pose,
  sons de brelan et écran d'activation des pouvoirs sont intégrés au mode réseau.
- Le lecteur musical réseau (⏮ ▶ ⏭, volume) se situe en haut à droite.
- « Pouvoir et animation » donne accès aux volumes et médias personnalisés.
- S'il manque des médias, vérifier les préférences de son et la présence des fichiers
  dans la bibliothèque sur CET ordinateur, puis cliquer sur ▶.

6. VERIFICATIONS ET LIMITES
- 38 tests automatisés réussis (logique, animation, glisser-déposer, confidentialité, dont 14 scénarios de pouvoir).
- Interface LAN testée dans Chromium : halo actif, tri pendant tour adverse,
  glisser maintenu pendant mises à jour et renouvellement de main animé, sans
  erreur JavaScript. Les tests navigateur ont été effectués hors réseau.
- Une connexion en réseau entre deux ordinateurs physiques n'a pas pu être vérifiée
  ici ; un test sur vos PC reste nécessaire.
- AVERTISSEMENT : deux moteurs de jeu distincts existent toujours sous le même
  HTML. La parité EXACTE des règles avancées, du Replay, des options IA, des
  avatars et de tous les effets secondaires N'EST PAS encore garantie.
  Le solo contenu dans cette version est la version originale intacte.
  Ne pas supprimer l'ancienne copie solo tant que vous n'avez pas vérifié vos médias.

7. FUTUR HEBERGEMENT INTERNET
- Le serveur Node.js est nécessaire ; l'HTML seul ne suffit pas pour 2 PC.
- Ne pas exposer tel quel le port 3000 sur Internet. Prévoir HTTPS/WSS, authentification
  et protection des salles, stockage et reconnexion avant une publication publique.

Sans installation npm supplémentaire : aucun paquet externe n'est requis pour jouer.
Pour exécuter les tests (optionnel) : npm test

CORRECTION IMPORT MEDIA — « assets is not a known object store name »
La version corrigée crée désormais automatiquement les magasins IndexedDB manquants,
y compris si une ancienne exportation a laissé une base vide version 1.
Fermer les autres onglets MARVEL FUSION avant de réimporter le Pack médias.
Il n'est pas nécessaire de vider le cache ni de supprimer les données du navigateur.

MISE A JOUR : GLISSER-DEPOSER DU MODE 2 JOUEURS (2026-10-30)
--------------------------------------------------------
Le glisser-deposer est disponible dans le mode reseau, a la souris ou au tactile :
1. Attendez votre tour, puis PIOCHEZ une carte.
2. Pour creer une combinaison : selectionnez trois cartes ou plus dans votre main,
   puis maintenez le clic sur l'une d'elles et glissez-la dans la zone de votre
   terrain ou du terrain adverse. Les cartes selectionnees voyagent ensemble.
3. Pour completer une combinaison : faites glisser une carte (ou une selection)
   directement SUR les cartes de la combinaison existante.
4. Pour remplacer Loki : faites glisser la vraie carte correspondante sur la
   combinaison contenant Loki.
Les regles de validite et le score restent verifies par le serveur.
Le systeme utilise un seul mecanisme de pointeur afin d'eviter les conflits
entre le glissement natif du navigateur et le glissement tactile/personnalise.

Installation : fermer l'ancien serveur, extraire TOUT le nouveau ZIP dans
un dossier, relancer LANCER_WINDOWS.bat sur le PC 1, puis actualiser les deux
navigateurs avec Ctrl+F5. Les deux PC ouvrent la meme adresse HTTP.

==============================================================
CORRECTIF 2 JOUEURS — GLISSER-DÉPOSER / GAME FEEL
==============================================================
Après la pioche, les cartes se glissent désormais avec la souris,
le doigt ou un stylet. Dépose trois cartes une à une sur TON terrain,
ou sélectionne-en plusieurs puis déplace le groupe. Glisse une carte
sur une combinaison existante (terrain allié ou adverse), ou sur la
pile Défausse à droite pour terminer le tour.

Dans la main, tu peux déplacer les cartes pour les réordonner, même
avant la pioche. L’ordre visuel est conservé pendant les mises à jour
réseau et les nouveaux tirages. Un défilement automatique aide sur
les petits écrans. Le clic simple de sélection fonctionne toujours.

Toutes les règles de pose et d’échange Loki restent validées côté
serveur. Voir CORRECTIF_GLISSER_DEPOSER.txt pour les détails.


MISE À JOUR GAME FEEL — HALO / TRI LIBRE / NOUVELLE MAIN (30/10/2026)
-------------------------------------------------------------------
- Au début de TON tour, la pioche scintille tant que tu n'as pas pioché.
  Le halo s'éteint dès que la pioche est effectuée et n'est pas visible
  chez le joueur non actif. Il utilise l'animation CSS du mode solo.
- Tu peux trier les cartes de ta main par glisser-déposer pendant ton tour
  OU le tour adverse, même avant de piocher et pendant un pouvoir adverse.
  Tri seul : aucune action n'est envoyée au serveur et aucune carte n'est jouée.
- Tu ne peux POSER ou DÉFAUSSER que lorsque c'est ton tour et APRÈS la pioche.
- Après la défausse de la dernière carte, après une défausse forcée ou un vol
  qui vide une main, le serveur y ajoute jusqu'à 8 cartes du paquet. Un effet
  visuel, un son de pioche et un message annoncent le renouvellement.
  Le recyclage de la défausse conserve sa carte supérieure, comme le solo.
  Si moins de 8 cartes restent réellement disponibles, on distribue ce
  qui reste. Pas de cartes créées ni dupliquées ; si le stock est entièrement
  épuisé, un message l'indique.
- Arrêter l'ancien serveur avant installation. Extraire le nouveau ZIP dans
  un dossier séparé, exécuter LANCER_WINDOWS.bat, actualiser les 2 navigateurs
  avec Ctrl+F5 et reprendre une partie.
