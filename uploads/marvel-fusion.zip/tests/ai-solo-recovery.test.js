'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const solo=JSON.parse(html.match(/<script id="mf-solo-src" type="application\/json">([\s\S]*?)<\/script>/)[1]);
test('La défausse humaine passe le tour à l’IA et programme son exécution',()=>{
  assert.match(solo,/state\.phase='ai';save\(\);render\(\);showTurnNotice\('ai'\);sfx\('discard'\);tactileFeedback\(\);scheduleAiTurn\(\)/);
});
test('Un minuteur IA suspendu ou perdu est détecté et relancé sans tour en doublon',()=>{
  assert.match(solo,/let aiTimerDueAt=0/);
  assert.match(solo,/aiTimer=setTimeout\(\(\)=>\{aiTimer=null;aiTimerDueAt=0;runAiTurn\(\);\},delay\)/);
  assert.match(solo,/Date\.now\(\)<aiTimerDueAt\+1600/);
  assert.match(solo,/if\(modalRoot\.querySelector\('\.mf-settings-dialog'\)\|\|aiAnimationBusy\)return/);
  assert.match(solo,/setInterval\(recoverInterruptedAiTurn,1600\)/);
  assert.match(solo,/window\.addEventListener\('pageshow',recoverInterruptedAiTurn\)/);
  assert.match(solo,/document\.addEventListener\('visibilitychange'/);
});
test('Un pouvoir IA en attente conserve sa fenêtre et ses choix',()=>{
  assert.match(solo,/if\(state\.pendingPower\)\{/);
  assert.match(solo,/showPowerDialog\(\)/);
});
