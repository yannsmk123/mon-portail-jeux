'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const code=mode=>JSON.parse(html.match(new RegExp('<script id="mf-'+mode+'-src" type="application/json">([\\s\\S]*?)<\\/script>'))[1]);
const solo=code('solo'),lan=code('lan');
test('Solo: le terrain inchangé ne recrée pas les cartes du DOM',()=>{
 assert.match(solo,/mfBoardHTMLCache=new Map\(\)/);
 assert.match(solo,/mfAiBoardToPaint/);
 assert.match(solo,/mfMyBoardToPaint/);
 assert.match(solo,/data-mf-render-revision/);
 assert.match(solo,/mfBoardHTMLCache\.set\(owner/);
});
test('Solo: le cache est invalidé lors des poses, sélections, images ou mode tactile',()=>{
 assert.match(solo,/ms\.map\(m=>\[m\.id,m\.kind,m\.owner,m\.cards\.map/);
 assert.match(solo,/boardSelectedLoki,prefs\.tabletMode,workshop\.links/);
 assert.match(solo,/memo\.assets===workshop\.assets/);
});
test('Réseau: les combinaisons conservées ne sont plus régénérées',()=>{
 assert.match(lan,/mfLanMeldHTMLCache=new Map\(\)/);
 assert.match(lan,/memo\.signature===signature&&memo\.active===active/);
 assert.match(lan,/mfLanMeldHTMLCache\.size>80/);
});
test('Réseau: le ciblage de fiche carte ne parcourt pas toutes les cartes posées',()=>{
 assert.match(lan,/mfLanPreviouslyMarkedCard/);
 assert.match(lan,/CSS\.escape\(String\(target\.id\)\)/);
});
test('Le bouton de récupération revient à la ligne dans les deux modes',()=>{
 for(const content of [solo,lan]){
   assert.match(content,/\.mf-piles \.mf-recover-discard\{/);
   assert.match(content,/white-space:normal!important;overflow-wrap:break-word/);
   assert.match(content,/height:auto;min-height:44px/);
 }
});
