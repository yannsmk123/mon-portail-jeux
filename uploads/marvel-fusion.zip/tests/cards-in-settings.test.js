const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const solo=JSON.parse(source.match(/<script id="mf-solo-src" type="application\/json">([\s\S]*?)<\/script>/)[1]);
const lan=JSON.parse(source.match(/<script id="mf-lan-src" type="application\/json">([\s\S]*?)<\/script>/)[1]);
test('Solo: Mes cartes ne prend plus de place dans la barre supérieure',()=>{
 const bar=solo.match(/<header class="topbar"[^>]*>([\s\S]*?)<\/header>/);
 assert.ok(bar);assert.doesNotMatch(bar[1],/workshop-nav|open-workshop/);
 assert.match(bar[1],/data-action="open-settings"/);
});
test('Solo: atelier ouvert via Paramètres → Mes cartes, sans modal qui recouvre',()=>{
 assert.match(solo,/data-tab="data" aria-selected="false">▤ Mes cartes/);
 assert.match(solo,/cardsPanel\.dataset\.mfTab='data'/);
 assert.match(solo,/data-action="open-workshop">▦ Ouvrir Mes cartes/);
 assert.match(solo,/if\(a==='open-workshop'\)\{modalRoot\.innerHTML=''/);
});
test('LAN: Mes cartes reste dans Paramètres, pas dans la barre',()=>{
 const header=lan.match(/<header class="topbar"[^>]*><nav class="top-actions">([\s\S]*?)<\/nav><\/header>/);
 assert.ok(header);assert.doesNotMatch(header[1],/openCards|Mes cartes/);
 assert.match(lan,/data-shared-tab="\$\{id\}"/);
 assert.match(lan,/data-shared-open-cards>▦ Mes cartes/);
 assert.match(lan,/if\(e\.target\.closest\('\[data-shared-open-cards\]'\)\)\{close\(\);\$id\('openCards'\)\?\.click\(\)/);
});
