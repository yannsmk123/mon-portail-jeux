'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const match=html.match(/<script id="mf-lan-src" type="application\/json">([\s\S]*?)<\/script>/);
assert.ok(match,'L’interface réseau doit exister dans le fichier HTML principal.');
const lan=JSON.parse(match[1]);

test('Les scripts réseau embarqués restent syntaxiquement valides',()=>{
  let count=0;
  for(const match of lan.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)){
    new vm.Script(match[1]);count++;
  }
  assert.ok(count>=2,'Scripts réseau et effets attendus.');
});

test('Le drag réseau n’active pas le drag HTML5 et garde le clic simple',()=>{
  assert.match(lan,/addEventListener\('dragstart'/);
  assert.match(lan,/e\.preventDefault\(\)/);
  assert.match(lan,/function canSortCards\(/);
  assert.match(lan,/function canDropCards\(/);
  assert.match(lan,/d\.slot\.setPointerCapture\(d\.id\)/);
  assert.doesNotMatch(lan,/slot\.setPointerCapture\(e\.pointerId\)/,'Ne pas capturer avant le seuil de drag, cela casserait le clic.');
});

test('Le mode 2 joueurs offre tous les dépôts et le tri de main',()=>{
  for(const pattern of [/function reorderHandAt\(/,/function displayHandOrder\(/,/function scrollDuringPointerDrag\(/,
    /kind:'new'/,/kind:'meld'/,/kind:'discard'/,/stagedIds=accumulated/,
    /type:'discard',cards:unique/,/offerMeld\(accumulated\)/,
    /offerMeld\(unique,target\.meld\)/]){
    assert.match(lan,pattern);
  }
});
