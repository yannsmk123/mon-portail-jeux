'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const source=name=>{
 const m=html.match(new RegExp('<script id="mf-'+name+'-src" type="application/json">([\\s\\S]*?)<\\/script>'));
 assert.ok(m,name+' existe');return JSON.parse(m[1]);
};
test('Le drag solo ajoute la carte tenue dans le plan du plein ecran',()=>{
 const solo=source('solo');
 assert.match(solo,/function mfDragVisualHost\(/);
 assert.match(solo,/mfDragVisualHost\(\)\.appendChild\(held\)/);
 assert.doesNotMatch(solo,/document\.body\.appendChild\(held\)/);
});
test('Le drag reseau et les animations de cartes utilisent le plan plein ecran',()=>{
 const lan=source('lan');
 assert.match(lan,/function mfDragVisualHost\(/);
 assert.match(lan,/mfDragVisualHost\(\)\.appendChild\(ghost\)/);
 assert.match(lan,/const host=mfDragVisualHost\(\);const node=document\.createElement\('div'\);node\.className='lan-fx-card'/);
 assert.doesNotMatch(lan,/document\.body\.appendChild\(ghost\)/);
});
test('Le plan visuel utilise la couche fullscreen si elle existe, body sinon',()=>{
 for(const name of ['solo','lan']){
  const src=source(name);
  assert.match(src,/document\.fullscreenElement\|\|document\.webkitFullscreenElement/);
  assert.match(src,/return full\|\|document\.body/);
 }
});
