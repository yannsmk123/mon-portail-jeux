const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const source=fs.readFileSync(require('node:path').join(__dirname,'..','index.html'),'utf8');
const a=source.match(/<script id="mf-lan-src" type="application\/json">([\s\S]*?)<\/script>/);
assert.ok(a,'Source LAN embedded');
const lan=JSON.parse(a[1]);
test('La barre LAN ne contient que les commandes principales et les modes ont le style natif',()=>{
 const nav=lan.match(/<header class="topbar"[^>]*><nav class="top-actions">([\s\S]*?)<\/nav><\/header>/);
 assert.ok(nav,'LAN topbar');
 assert.doesNotMatch(nav[1],/id="openCards"|id="lanOpenEffects"|>Mode solo</);
 assert.match(nav[1],/id="openSettings"/);
 assert.match(source,/nav\.prepend\(host\)/);
 assert.match(source,/class="ghost-btn" data-mode="home"/);
 assert.match(source,/class="ghost-btn" data-mode="solo"/);
 const fn=source.slice(source.indexOf('function installEmbeddedToolbar(){'),source.indexOf('function mode(next)'));
 assert.doesNotMatch(fn,/data-mode="reseau"/);
});
test('Les vrais boutons de personnalisation sont dans Paramètres et restent branchés',()=>{
 const prefs=lan.match(/<div class="shade hide" id="prefsDialog">([\s\S]*?)<\/section><\/div><script>/);
 assert.ok(prefs);
 assert.match(prefs[1],/id="openCards"/);
 assert.match(prefs[1],/id="lanOpenEffects"/);
 assert.equal((lan.match(/id="openCards"/g)||[]).length,1);
 assert.equal((lan.match(/id="lanOpenEffects"/g)||[]).length,1);
 assert.match(lan,/\$\('openCards'\)\.onclick=.*?mediaDialog.*?classList\.remove\('hide'\)/);
 assert.match(lan,/btn\.onclick=\(\)=>\{\$id\('prefsDialog'\)\.classList\.add\('hide'\);\$id\('lanEffects'\)/);
});
