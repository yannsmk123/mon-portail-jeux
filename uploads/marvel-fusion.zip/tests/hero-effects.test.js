'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {rooms,start,move,view}=require('../server');
let serial=0;
function room(){const code='FX'+String(++serial).padStart(4,'0');const r={code,players:[{name:'A'},{name:'B'}],phase:'lobby',events:[],version:0};rooms.set(code,r);start(r,{lokis:4,first:0});r.game.scores=[12,12];r.game.drawn=true;return r;}
function verify(g){const all=[...g.deck,...g.discard,...g.hands.flat(),...g.melds.flatMap(x=>x.cards)];assert.equal(all.length,84);assert.equal(new Set(all.map(x=>x.id)).size,84);}
function activate(r,n){r.game.pending={by:0,stage:'activate',number:n,name:'Héros '+n};move(r,0,{type:'power'});return r.game;}
function pick(r){const opts=view(r,0).game.powerChoices;assert(opts.length>0);move(r,0,{type:'power-choice',choice:'pick',card:opts[0].id});return opts[0]}
for(const [id,name,check] of [
 [0,'Hulk',(r,g)=>{assert.equal(g.scores[1],7);assert.equal(g.pending,null)}],
 [1,'Iron Man',(r,g)=>{assert.equal(g.scores[0],17);assert.equal(g.pending,null)}],
 [2,'Dr Strange',(r,g,pre)=>{assert.equal(g.hands[0].length,pre.a+2);assert.equal(g.pending.stage,'observe');assert.deepEqual(view(r,0).game.powerChoices.map(c=>c.id),g.hands[1].map(c=>c.id));assert.equal(view(r,1).game.powerChoices.length,0);move(r,0,{type:'power-choice',choice:'continue'})}],
 [3,'Black Panther',(r,g,pre)=>{assert.equal(g.pending.remaining,2);pick(r);assert.equal(g.pending.remaining,1);pick(r);assert.equal(g.hands[1].length,pre.b-2);assert.equal(g.discard.length,pre.d+2)}],
 [4,'Captain America',(r,g)=>{assert.equal(g.scores[0],15);assert.equal(g.shields[0],true);assert.equal(view(r,0).game.shields[0],true);assert.equal(view(r,1).game.shields[0],true)}],
 [5,'Thor',(r,g,pre)=>{assert.equal(g.hands[0].length,pre.a+2);pick(r);assert.equal(g.hands[1].length,pre.b-1)}],
 [6,'Spider-Man',(r,g,pre)=>{const picked=pick(r);assert.equal(g.hands[0].length,pre.a+1);assert.equal(g.hands[1].length,pre.b-1);assert(g.hands[0].some(c=>c.id===picked.id))}],
 [7,'Groot',(r,g,pre)=>{const available=g.deck.slice(-3).map(c=>c.id);assert.deepEqual(new Set(view(r,0).game.powerChoices.map(c=>c.id)),new Set(available));const picked=pick(r);assert(g.hands[0].some(c=>c.id===picked.id));assert.equal(g.hands[0].length,pre.a+1);assert.equal(g.deck.length,pre.deck-1)}],
 [8,'Magneto',(r,g,pre)=>{const choices=view(r,0).game.powerChoices;assert.equal(choices.length,pre.a);for(let i=0;i<3;i++)move(r,0,{type:'power-choice',choice:'toggle',card:choices[i].id});assert.equal(g.pending.chosen.length,3);move(r,0,{type:'power-choice',choice:'confirm'});assert.equal(g.hands[0].length,pre.a);assert.equal(g.discard.length,pre.d+3)}],
 [9,'Hela',(r,g,pre)=>{assert.equal(g.scores[1],9);pick(r);assert.equal(g.hands[1].length,pre.b-1)}],
 [10,'Venom',(r,g,pre)=>{assert.equal(g.hands[0].length,pre.a+2);pick(r);assert.equal(g.hands[1].length,pre.b-1)}],
 [11,'Star-Lord',(r,g)=>{assert.equal(g.scores[1],10);assert.equal(g.scores[0],14)}],
 [12,'Rocket Raccoon',(r,g,pre)=>{assert.equal(g.hands[0].length,pre.a+2);assert.equal(g.scores[0],13)}],
 [13,'Punisher',(r,g,pre)=>{assert.equal(g.pending.stage,'punisher');const opts=view(r,0).game.powerChoices;assert.deepEqual(opts.map(c=>c.id),g.discard.slice(-3).reverse().map(c=>c.id));const picked=pick(r);assert(g.hands[0].some(c=>c.id===picked.id));assert.equal(g.discard.length,pre.d-1)}]
]) test(`Effet réel ${id} — ${name}`,()=>{
 const r=room(),g=r.game;
 if(id===13)g.discard.push(...g.deck.splice(-3));
 const pre={a:g.hands[0].length,b:g.hands[1].length,d:g.discard.length,deck:g.deck.length};
 activate(r,id);check(r,g,pre);
 assert.equal(g.pending,null,`pouvoir ${id} terminé`);verify(g);rooms.delete(r.code);
});
test('Captain America protège contre Hulk, Hela et Star-Lord puis expire au prochain tour',()=>{
 const r=room(),g=r.game;g.shields[0]=true;g.scores=[14,14];
 g.current=1;g.pending={by:1,number:0,stage:'activate',name:'Hulk'};move(r,1,{type:'power'});assert.equal(g.scores[0],14);
 g.pending={by:1,number:9,stage:'activate',name:'Hela'};move(r,1,{type:'power'});pickOwner(r,1);assert.equal(g.scores[0],14);
 g.pending={by:1,number:11,stage:'activate',name:'Star-Lord'};move(r,1,{type:'power'});assert.equal(g.scores[0],14);assert.equal(g.scores[1],14);
 g.pending=null;g.drawn=true;move(r,1,{type:'discard',cards:[g.hands[1][0].id]});assert.equal(g.current,0);assert.equal(g.shields[0],false);verify(g);rooms.delete(r.code)
});
function pickOwner(r,side){const opts=view(r,side).game.powerChoices;move(r,side,{type:'power-choice',choice:'pick',card:opts[0].id})}
test('Carte LAN : structure identique au solo, classes et indicateurs de Loki présents',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
 const get=(id)=>{const m=html.match(new RegExp(`<script id="mf-${id}-src" type="application/json">([\\s\\S]*?)<\\/script>`));assert(m);return JSON.parse(m[1]);};
 const solo=get('solo'),lan=get('lan');
 const firstSoloCss=solo.match(/<style>([\s\S]*?)<\/style>/)[1],firstLanCss=lan.match(/<style>([\s\S]*?)<\/style>/)[1];
 assert(firstLanCss.startsWith(firstSoloCss),'La feuille CSS originale solo doit être strictement conservée');
 assert(lan.includes('class="run-number${isJ?\' run-loki\':\'\'}"'));
 for(const k of ['stacked-card','class="assigned"','card-illustration-shade','mf-parite-cartes-css','lan-shield-indicator'])assert(lan.includes(k),k);
 assert.equal((solo.match(/const HERO_POWERS=\{/g)||[]).length,1);
 assert(lan.includes('Punisher'));
});
