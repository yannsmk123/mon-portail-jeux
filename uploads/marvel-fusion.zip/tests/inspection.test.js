'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {readFileSync}=require('node:fs');
const {join}=require('node:path');
const source=readFileSync(join(__dirname,'../index.html'),'utf8');
function mode(id){const found=source.match(new RegExp(`<script id="mf-${id}-src" type="application/json">([\\s\\S]*?)<\\/script>`));assert(found);return JSON.parse(found[1]);}
const lan=mode('lan'),solo=mode('solo');

test('Le SFX hover couvre les mains et les deux terrains en LAN, même pendant le tour adverse',()=>{
 assert.match(lan,/const lanInspectCardSelector='[^']*#game #myHand \.card\[data-card-id\][^']*#game #myMelds [^']*#game #enemyMelds [^']*'/);
 assert.match(lan,/document\.addEventListener\('pointerover',e=>\{[\s\S]*?sound\('hover'\)/);
 assert.match(lan,/card\.contains\(e\.relatedTarget\)/);
 assert.doesNotMatch(lan,/state\?\.phase==='turn'\)sound\('hover'\)/);
});
test('Le clic droit ouvre les informations pour les cartes réellement visibles, sans divulguer les mains adverses',()=>{
 assert.match(lan,/document\.addEventListener\('contextmenu',e=>\{/);
 assert.match(lan,/e\.preventDefault\(\);showLanCardInspection\(card\)/);
 assert.match(lan,/view\.game\.hands\[view\.me\]\?\.find/);
 assert.match(lan,/view\.game\.melds\.find/);
 assert.doesNotMatch(lan,/view\.game\.hands\[1-view\.me\]\?\.find/);
 assert.match(lan,/data-card-id="\$\{esc\(c\.id\)\}"/);
});
test('La fiche copie les textes des 14 héros et la présentation 3D du solo',()=>{
 const match=solo.match(/const HERO_POWERS=\{([\s\S]*?)\n\s*\};/);
 assert(match,'Les descriptions doivent exister dans le solo');
 for(const line of match[1].trim().split(/\n/)){
  const row=line.trim().replace(/,$/,'');
  assert(lan.includes(row),`Description manquante : ${row}`);
 }
 for(const component of ['card-3d-scene','card-3d-body','card-3d-gloss','card-detail-info','card-detail-notes','mf-card-inspection-backdrop']){
  assert(lan.includes(component),`Composant solo absent : ${component}`);
 }
 assert.match(lan,/workshop\.details\?\.\[ctype\(card\)\]/);
});
test('La fenêtre ferme avec Échap, bouton et fond sans interférer avec la sélection et le tri',()=>{
 assert.match(lan,/data-lan-close-inspection/);
 assert.match(lan,/if\(e\.key==='Escape'&&!\$id\('lanCardInspection'\)/);
 assert.match(lan,/if\(e\.target===layer\|\|e\.target\.closest\('\[data-lan-close-inspection\]'\)\)/);
 assert.match(lan,/function canSortCards\(\)/);
 assert.match(lan,/d\.slot\.setPointerCapture\(d\.id\)/);
});
test('Loki garde son affectation dans la vue d’inspection 3D',()=>{
 assert.match(lan,/function cardHTML\(c,\{small=false,clickable=false,showAssignment=false\}=\{\}\)/);
 assert.match(lan,/\(small\|\|showAssignment\)&&isJ&&Number\.isInteger\(c\.asN\)/);
 assert.match(lan,/cardHTML\(card,\{showAssignment:true\}\)/);
});
