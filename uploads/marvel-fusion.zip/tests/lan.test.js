const {test,after}=require('node:test');const assert=require('node:assert/strict');const {server,rooms,meldCandidates,deck,move,start,view}=require('../server');
let origin;test('Démarrage HTTP local',async()=>{await new Promise(ok=>server.listen(0,'127.0.0.1',ok));origin='http://127.0.0.1:'+server.address().port;const r=await fetch(origin+'/health');assert.equal(r.status,200);assert.equal((await r.json()).ok,true)});
test('Accès à l’accueil et liens depuis le PC 2',async()=>{
  for(const route of ['/', '/index.html', '/jeu']){
    const r=await fetch(origin+route);
    assert.equal(r.status,200,route);
    assert.match(r.headers.get('content-type')||' ',/text\/html/);
    assert.match(await r.text(),/MARVEL FUSION/);
  }
  const health=await (await fetch(origin+'/health')).json();
  assert.equal(health.jeu,origin+'/');
  assert.equal(health.diagnostic,origin+'/diagnostic');
  const diag=await fetch(health.diagnostic);
  assert.equal(diag.status,200);
  assert.match(await diag.text(),/OUVRIR LE JEU/);
});
async function post(route,obj){const r=await fetch(origin+'/api/'+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(obj)});return {status:r.status,data:await r.json()}}
test('Création, salle à deux, troisième refusé, mains secrètes',async()=>{let a=(await post('create',{name:'Alice'})).data;assert.equal(a.side,0);let b=(await post('join',{code:a.code,name:'Bob'})).data;assert.equal(b.side,1);assert.equal((await post('join',{code:a.code,name:'Eve'})).status,400);let st=await post('start',{...a,lokis:4,first:0});assert.equal(st.status,200);assert.equal(st.data.game.hands[0].length,8);assert.equal(typeof st.data.game.hands[1],'number');let other=(await post('state',b)).data;assert.equal(other.game.hands[1].length,8);assert.equal(typeof other.game.hands[0],'number');assert.equal((await post('state',{code:a.code,token:'invalide'})).status,400);assert.equal((await post('move',{...b,type:'draw',source:'deck'})).status,400);assert.equal((await post('move',{...a,type:'draw',source:'deck'})).status,200);assert.equal((await post('move',{...a,type:'draw',source:'deck'})).status,400);assert.equal((await post('move',{...a,type:'discard',cards:['ID_FAUX']})).status,400);const h=(await post('state',a)).data.game.hands[0];assert.equal((await post('move',{...a,type:'discard',cards:[h[0].id]})).status,200);assert.equal((await post('state',b)).data.game.current,1);});
test('Règles de combinaison : suites, Loki, doublon refusé',()=>{let c=(n,suit,id)=>({n,suit,id,joker:false}),j=(id)=>({n:null,suit:null,id,joker:true});assert.ok(meldCandidates([c(2,'red','a'),c(3,'red','b'),c(4,'red','c')]).some(x=>x.kind==='run'));assert.equal(meldCandidates([c(2,'red','a'),c(2,'red','b'),c(4,'red','c')]).length,0);assert.ok(meldCandidates([c(3,'green','a'),c(4,'green','b'),j('k')]).some(x=>x.cards.some(z=>z.joker&&z.asN===5)));assert.ok(meldCandidates([c(0,'green','a'),c(2,'green','b'),j('j')]).some(x=>x.cards.some(z=>z.joker&&z.asN===1)));
assert.equal(meldCandidates([c(0,'green','a'),c(2,'blue','b'),j('j')]).length,0);assert.ok(meldCandidates([c(5,'red','a'),c(5,'blue','b'),c(5,'yellow','c')]).some(x=>x.kind==='set'));});
test('240 parties de séquences aléatoires, contrôle des cartes',()=>{for(let run=0;run<240;run++){const r={players:[{name:'A'},{name:'B'}],events:[],version:0,phase:'lobby'};start(r,{lokis:4,first:run%2});for(let t=0;t<65&&r.phase==='playing';t++){let g=r.game,p=g.current;if(!g.drawn){try{move(r,p,{type:'draw',source:g.deck.length?'deck':'discard'})}catch{break}}let h=g.hands[p];let played=false;outer:for(let a=0;a<h.length;a++)for(let b=a+1;b<h.length;b++)for(let c=b+1;c<h.length;c++){const ids=[h[a].id,h[b].id,h[c].id];if(h.length<=3)break outer;try{move(r,p,{type:'meld',cards:ids});played=true;break outer}catch{}}if(g.pending){try{move(r,p,{type:'power'})}catch(e){throw e}}if(!g.hands[p].length)break;move(r,p,{type:'discard',cards:[g.hands[p][0].id]});let cards=[...g.deck,...g.discard,...g.hands.flat(),...g.melds.flatMap(m=>m.cards)];assert.equal(cards.length,84,'Conservation des cartes (80 originales + 4 Loki)');assert.equal(new Set(cards.map(x=>x.id)).size,84,'Aucun doublon');assert.ok(g.scores.every(Number.isFinite))}}});
test('Partie refusée sans second joueur',()=>{const r={players:[{name:'A'},null],events:[],version:0,phase:'lobby'};assert.equal(r.players[1],null)});
after(async()=>{await new Promise(ok=>server.close(ok))});
