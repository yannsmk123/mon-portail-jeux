'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
function inner(name){const m=html.match(new RegExp(`<script id="mf-${name}-src" type="application/json">([\\s\\S]*?)<\\/script>`));assert.ok(m);return JSON.parse(m[1]);}
const solo=inner('solo'),lan=inner('lan');
test('Les quatre bases du solo s’ouvrent à leur version existante, sans VersionError',()=>{
 for(const key of ['MF_AUDIO_DB','MF_POWER_ANIM_DB','MF_OUTCOME_DB','WORKSHOP_DB']){
  assert.ok(solo.includes('indexedDB.open('+key+')'),'base '+key);
  assert.ok(!solo.includes('indexedDB.open('+key+',1)'),'version figée pour '+key);
 }
});
test('Les deux bases LAN s’ouvrent sans version figée',()=>{
 assert.ok(lan.includes("indexedDB.open('mf-lan-workshop-v1')"));
 assert.ok(lan.includes('indexedDB.open(dbName)'));
 assert.ok(!lan.includes("indexedDB.open('mf-lan-workshop-v1',1)"));
 assert.ok(!lan.includes('indexedDB.open(dbName,1)'));
});
test('L’import automatique ne se fie pas au hash sans contrôle des fichiers réellement installés',()=>{
 assert.match(html,/async function mfMediaReallyInstalled\(meta\)/);
 assert.match(html,/localStorage\.getItem\(MF_SITE_MEDIA_SHA_KEY\)===meta.sha256/);
 assert.match(html,/await mfMediaReallyInstalled\(meta\)/);
 assert.match(html,/localStorage\.removeItem\(MF_SITE_MEDIA_SHA_KEY\)/);
 assert.match(html,/id="mf-site-media-retry"/);
});
