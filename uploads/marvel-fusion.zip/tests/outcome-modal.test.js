'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const lan=JSON.parse(html.match(/<script id="mf-lan-src" type="application\/json">([\s\S]*?)<\/script>/)[1]);
test('Victoire et défaite ne créent plus de bandeau dans le plateau',()=>{
 assert.doesNotMatch(lan,/id="winner"/);
 assert.match(lan,/id="lanOutcomeOverlay"/);
 assert.match(lan,/mf-outcome-result-shade/);
 assert.match(lan,/aria-modal="true" aria-labelledby="lanOutcomeTitle"/);
});
test('La fenêtre comprend classement, médias et actions solo',()=>{
 assert.match(lan,/function showOutcome\(j,\{replay=false\}=\{\}\)/);
 assert.match(lan,/data-lan-outcome=\\"replay\\"|data-lan-outcome="replay"/);
 assert.match(lan,/data-lan-outcome="close"/);
 assert.match(lan,/data-lan-outcome="home"/);
 assert.match(lan,/result-rank/);
 assert.match(lan,/lastResult===key/);
 assert.match(lan,/closeLanOutcome\(\)/);
});
