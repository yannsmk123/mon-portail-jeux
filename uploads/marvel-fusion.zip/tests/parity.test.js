'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {rooms,start,move,view,previewMeld}=require('../server');
const html=fs.readFileSync(require('node:path').join(__dirname,'../index.html'),'utf8');
function mode(id){const re=new RegExp(`<script id="mf-${id}-src" type="application/json">([\\s\\S]*?)<\\/script>`);const match=html.match(re);assert(match,`Mode ${id} intégré`);return JSON.parse(match[1]);}
const solo=mode('solo'),lan=mode('lan');
let codeNumber=0;
function room(){const code='PAR'+String(++codeNumber).padStart(3,'0');const r={code,players:[{name:'A'},{name:'B'}],events:[],version:0,phase:'lobby'};rooms.set(code,r);start(r,{lokis:4,first:0});return r;}
function take(g,predicate){for(const hand of [g.deck,g.hands[0],g.hands[1],g.discard]){const index=hand.findIndex(predicate);if(index!==-1)return hand.splice(index,1)[0]}throw Error('Carte absente');}
test('Les 13 évènements SFX et leurs tonalités sont exactement les mêmes que dans le solo',()=>{
 const chords=/const chords=(\{[^;]+\});/;
 assert(solo.match(chords),'Définition originale SFX solo');assert(lan.match(chords),'Définition SFX LAN');
 assert.equal(lan.match(chords)[1],solo.match(chords)[1]);
 for(const k of ['hover','select','draw','place','brelan','moveToBoard','discard','loki','victory','defeat','invalid','menu','turn']){assert(lan.includes(k+':'),k+' présent dans LAN');assert(solo.includes(k+':'),k+' présent dans solo');}
});
test('Les deux modes intègrent la même palette et les mêmes keyframes de base',()=>{
 for(const anim of ['card-arrive','mf-card-deal','mf-meld-pop','mf-power-media-enter','mf-power-halo-border','scoreFloat','mfDrawHalo']){
  assert(solo.includes('@keyframes '+anim),'Solo '+anim);assert(lan.includes('@keyframes '+anim),'LAN '+anim);
 }
});
test('Pouv. : les phases de choix et les cartes visibles arrivent bien sur le navigateur propriétaire',()=>{
 for(let n=0;n<=13;n++){
  const r=room(),g=r.game;g.current=0;g.drawn=true;g.pending={by:0,number:n,name:'Personnage',stage:'activate'};
  assert.equal(view(r,0).game.pending.stage,'activate');
  move(r,0,{type:'power'});
  if(g.pending){const own=view(r,0).game,other=view(r,1).game;
   assert.equal(own.pending.stage,g.pending.stage,'Phase '+n);
   assert.equal(own.pending.remaining,g.pending.remaining??0,'Restant '+n);
   assert.equal(other.pending.stage,g.pending.stage,'Adversaire informé sans carte révélée');
   assert.equal(other.powerChoices.length,0,'Choix non transmis à adversaire');
   assert.equal(other.revealedHand,null,'Mains non divulguées');
   let loop=0;
   while(g.pending){assert(++loop<11,'Pouvoir '+n+' terminé');let stage=g.pending.stage,options=view(r,0).game.powerChoices;
    if(stage==='observe')move(r,0,{type:'power-choice',choice:'continue'});
    else if(stage==='magneto'){
     if(!g.pending.chosen.length&&options.length>=2){move(r,0,{type:'power-choice',choice:'toggle',card:options[0].id});assert.deepEqual(view(r,0).game.pending.chosen,[options[0].id]);assert.deepEqual(view(r,1).game.pending.chosen,[]);}
     move(r,0,{type:'power-choice',choice:'confirm'});
    }else{assert(options.length>0);move(r,0,{type:'power-choice',choice:'pick',card:options[0].id});}
   }
  }rooms.delete(r.code);
 }
});
test('Compléter un carré via échange Loki déclenche le même héros que le solo',()=>{
 const r=room(),g=r.game,n=5,suits=['red','blue','yellow','green'];
 const real=suits.map(s=>take(g,c=>!c.joker&&c.n===n&&c.suit===s));
 const joker=take(g,c=>c.joker);
 g.melds.push({id:'power-meld',owner:1,kind:'set',cards:[...real.slice(0,3).map(c=>({...c,asN:c.n,asSuit:c.suit})),{...joker,asN:n,asSuit:'green'}]});
 g.hands[0].push(real[3]);g.drawn=true;
 move(r,0,{type:'swap',cards:[real[3].id],meld:'power-meld'});
 assert.equal(g.pending.stage,'activate');assert.equal(g.pending.number,5);
 assert.equal(g.actions.at(-1).kind,'power-ready');
 assert.equal(view(r,0).game.pending.stage,'activate');
 move(r,0,{type:'power'});assert.equal(view(r,0).game.pending.stage,'enemy-discard');
 const cards=[...g.deck,...g.discard,...g.hands.flat(),...g.melds.flatMap(m=>m.cards)];
 assert.equal(cards.length,84);assert.equal(new Set(cards.map(c=>c.id)).size,84);
 rooms.delete(r.code);
});
test('Défausse dernière carte : la main est renouvelée comme en solo',()=>{
 const r=room(),g=r.game;g.drawn=true;
 while(g.hands[0].length>1)g.deck.push(g.hands[0].pop());
 move(r,0,{type:'discard',cards:[g.hands[0][0].id]});
 assert.equal(g.hands[0].length,8);assert.equal(g.current,1);rooms.delete(r.code);
});
test('Défausse forcée dernière carte : main adverse reconstituée',()=>{
 const r=room(),g=r.game;g.drawn=true;
 while(g.hands[1].length>1)g.deck.push(g.hands[1].pop());
 g.pending={by:0,number:3,name:'Black Panther',stage:'enemy-discard',remaining:1};
 const victim=g.hands[1][0];
 move(r,0,{type:'power-choice',choice:'pick',card:victim.id});
 assert.equal(g.hands[1].length,8);assert.equal(g.pending,null);rooms.delete(r.code);
});

test('Loki : le LAN propose les affectations multiples et respecte le choix du joueur',()=>{
 const r=room(),g=r.game,n=4;g.drawn=true;
 const cards=[take(g,c=>!c.joker&&c.n===n&&c.suit==='red'),take(g,c=>!c.joker&&c.n===n&&c.suit==='blue'),take(g,c=>c.joker)];
 g.hands[0].push(...cards);
 const options=previewMeld(r,0,{cards:cards.map(c=>c.id)});
 assert.equal(options.length,2);
 assert.deepEqual(options.map(o=>o.lokis[0].asSuit),['yellow','green']);
 const before=r.version;assert.equal(g.melds.length,0);assert.equal(r.version,before,'La prévisualisation ne modifie pas la partie');
 move(r,0,{type:'meld',cards:cards.map(c=>c.id),variant:1});
 assert.equal(g.melds[0].cards.find(c=>c.joker).asSuit,'green');
 const seen=[...g.deck,...g.discard,...g.hands.flat(),...g.melds.flatMap(m=>m.cards)];
 assert.equal(seen.length,84);assert.equal(new Set(seen.map(x=>x.id)).size,84);
 rooms.delete(r.code);
});
test('Le serveur refuse un index de Loki truqué',()=>{
 const r=room(),g=r.game;g.drawn=true;
 const cards=[take(g,c=>!c.joker&&c.n===6&&c.suit==='red'),take(g,c=>!c.joker&&c.n===6&&c.suit==='blue'),take(g,c=>c.joker)];
 g.hands[0].push(...cards);
 assert.throws(()=>move(r,0,{type:'meld',cards:cards.map(c=>c.id),variant:900}),/Variante/);
 assert.equal(g.melds.length,0);rooms.delete(r.code);
});
