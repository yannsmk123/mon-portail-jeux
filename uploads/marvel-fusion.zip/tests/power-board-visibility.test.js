'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const html=fs.readFileSync(require('node:path').join(__dirname,'..','index.html'),'utf8');
const embedded=html.match(/<script id="mf-lan-src" type="application\/json">([\s\S]*?)<\/script>/);
assert.ok(embedded,'Le mode LAN embarqué doit être présent');
const lan=JSON.parse(embedded[1]);
test('Le pouvoir apparaît dans un panneau non modal avec plateau visible',()=>{
 assert.match(lan,/#lanPowerOverlay\.lan-power-modal\s*\{[^}]*background:transparent!important/s);
 assert.match(lan,/#lanPowerOverlay\.lan-power-modal\s*\{[^}]*pointer-events:none!important/s);
 assert.match(lan,/#lanPowerOverlay \.lan-power-screen\s*\{[^}]*pointer-events:auto!important/s);
 assert.match(lan,/role="region" aria-label="Pouvoir de/);
 assert.doesNotMatch(lan,/role="dialog" aria-modal="true" aria-label="Pouvoir de/);
});
test('Les choix et l’activation restent disponibles pendant que le terrain est visible',()=>{
 assert.match(lan,/data-power-action="power"/);
 assert.match(lan,/data-power-action="continue"/);
 assert.match(lan,/data-power-action="confirm"/);
 assert.match(lan,/data-power-action="\$\{stage===/);
 assert.match(lan,/data-lan-power-toggle/);
 assert.match(lan,/powerDockCollapsed=!powerDockCollapsed/);
 assert.match(lan,/\.lan-power-screen\.is-collapsed \.lan-power-content\{display:none\}/);
});
test('Le pouvoir adverse reste consultable ; le mobile utilise un panneau inférieur',()=>{
 assert.match(lan,/modal\.classList\.toggle\('lan-passive-power',!isMine\)/);
 assert.match(lan,/@media\(max-width:760px\)\{[\s\S]*?#lanPowerOverlay\.lan-power-modal/);
 assert.match(lan,/powerDockStage!==stage/);
 assert.match(lan,/function afterRender\(j,previous,snap\)/);
});
