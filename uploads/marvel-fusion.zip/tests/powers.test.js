'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {rooms,start,move,view,meldCandidates}=require('../server');
let seq=0;
function room(){const code='POW'+String(++seq).padStart(3,'0');const r={code,players:[{name:'A',token:'one',online:true},{name:'B',token:'two',online:true}],phase:'lobby',version:0,updated:Date.now(),events:[]};rooms.set(code,r);start(r,{lokis:4,first:0});return r}
const cardCount=g=>g.deck.length+g.hands[0].length+g.hands[1].length+g.discard.length+g.melds.reduce((n,m)=>n+m.cards.length,0);
const unique=g=>{const cards=[...g.deck,...g.discard,...g.hands[0],...g.hands[1],...g.melds.flatMap(m=>m.cards)];assert.equal(cards.length,84);assert.equal(new Set(cards.map(c=>c.id)).size,84)};
for(let n=0;n<=13;n++){
 test(`Pouvoir ${n} : activation, choix, confidentialité et conservation`,()=>{
   const r=room(),g=r.game;g.pending={by:0,number:n,name:'Héros '+n,stage:'activate'};g.drawn=true;g.scores=[0,10];
   move(r,0,{type:'power'});
   let count=0;
   while(g.pending){
     assert(++count<10,'Le pouvoir doit pouvoir se terminer');
     const stage=g.pending.stage,opts=view(r,0).game.powerChoices;
     const oview=view(r,1).game;
     assert.equal(oview.powerChoices.length,0,'Seul le propriétaire peut choisir.');
     assert.equal(oview.revealedHand,null,'La main adverse ne doit pas fuiter.');
     if(stage==='observe')move(r,0,{type:'power-choice',choice:'continue'});
     else if(stage==='magneto')move(r,0,{type:'power-choice',choice:'confirm'});
     else{assert(opts.length>0,stage+' ne propose aucune carte');move(r,0,{type:'power-choice',choice:'pick',card:opts[0].id});}
   }
   unique(g);assert.equal(cardCount(g),84);
   rooms.delete(r.code)
 });
}
test('Un joueur ne peut pas activer le pouvoir adverse',()=>{const r=room();r.game.pending={by:0,number:1,name:'Iron Man',stage:'activate'};assert.throws(()=>move(r,1,{type:'power'}),/tour/);rooms.delete(r.code)});
test('La pose publie une action répliquable et conserve les identités',()=>{const r=room(),g=r.game;g.drawn=true;
 const c=g.deck;function take(n,s){for(const list of [g.deck,g.hands[0],g.hands[1]]){let i=list.findIndex(x=>!x.joker&&x.n===n&&x.suit===s);if(i>=0)return list.splice(i,1)[0]}};
 const three=[take(1,'red'),take(2,'red'),take(3,'red')];assert(three.every(Boolean));g.hands[0].push(...three);
 move(r,0,{type:'meld',cards:three.map(x=>x.id)});
 const a=g.actions.at(-1);assert.equal(a.kind,'pose');assert.equal(a.meldKind,'run');assert.equal(a.cards.length,3);assert.equal(a.result.length,3);unique(g);rooms.delete(r.code)
});
