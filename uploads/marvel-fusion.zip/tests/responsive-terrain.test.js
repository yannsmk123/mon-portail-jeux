'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const page=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const source=mode=>{
 const match=page.match(new RegExp(`<script id="mf-${mode}-src" type="application/json">([\\s\\S]*?)<\\/script>`));
 assert.ok(match,`source ${mode} présent`);
 return JSON.parse(match[1]);
};
for(const mode of ['solo','lan']){
 test(`Terrain ${mode}: disposition fluide sans ascenseur interne hors plein écran`,()=>{
  const html=source(mode);
  assert.match(html, /mf-responsive-terrain-no-inner-scroll/);
  assert.match(html,/overflow-x:visible!important;overflow-y:visible!important/);
  assert.match(html,/grid-template-rows:auto 2px auto!important/);
  assert.match(html,/\.mf-meld-band/);
 });
}
test('Solo : aucun sous-texte dans le titre du tour',()=>{
 const html=source('solo');
 assert.doesNotMatch(html, /Tour de \$\{safe\(state\.names\[0\]\)\}`\}\s*<small>/);
});
test('Réseau : texte secondaire de tour supprimé sans mise à jour JS résiduelle',()=>{
 const html=source('lan');
 assert.doesNotMatch(html,/id="turnDetail"/);
 assert.doesNotMatch(html,/\$\('turnDetail'\)\.textContent/);
});
