const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const file=fs.readFileSync(require('node:path').join(__dirname,'..','index.html'),'utf8');
function source(mode){const m=file.match(new RegExp(`<script id="mf-${mode}-src" type="application/json">([\\s\\S]*?)<\\/script>`)); assert.ok(m,mode);return JSON.parse(m[1]);}
const solo=source('solo'),lan=source('lan');
const prefs=['sound','volume','musicVolume','musicEnabled','motion','quality','glow','theme','compact','boardCardSize','handCardSize','powerFx','powerFxDuration','animPosePlayer','animPoseAI','animPoints','animToDiscard'];
test('Même clé canonique de paramètres solo et réseau',()=>{assert.match(solo,/PREF_KEY='marvel-fusion-settings-v1'/);assert.match(lan,/MF_SHARED_KEY='marvel-fusion-settings-v1'/);assert.match(lan,/saveSharedFromLAN\(\{/);});
test('Les principaux paramètres du solo sont présents dans le panneau LAN',()=>{for(const key of prefs)assert.ok(lan.includes(key),'Réglage absent : '+key);});
test('Le panneau LAN propose les catégories de réglages du solo',()=>{for(const category of ['Affichage','Sons et SFX','Jouabilité','Animations','Pouvoir et animation'])assert.ok(lan.includes(category),category);assert.match(lan,/function showUnifiedSettings/);});
test('LAN -> Solo : partage des médias audio, pouvoirs et issues de partie',()=>{for(const s of ["marvel-fusion-audio-v1","marvel-fusion-power-animations-v1","marvel-fusion-outcomes-v1"])assert.ok(lan.includes(s));assert.match(lan,/mirrorLanAssetToSolo\(key/);});
test('Solo -> LAN : synchronisation automatique des bibliothèques',()=>{assert.match(solo,/mirrorToLan\('powerVisual:'/);assert.match(solo,/mirrorToLan\('outcome:'/);assert.match(solo,/mirrorToLan\(item\.type==='music'/);});
test('Les ateliers de cartes sont synchronisés dans les deux sens',()=>{assert.match(solo,/mirrorWorkshopLan\(data\)/);assert.match(lan,/indexedDB\.open\('marvel-fusion-workshop-1'\)/);});
