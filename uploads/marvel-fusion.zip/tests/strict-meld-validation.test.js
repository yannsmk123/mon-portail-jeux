'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {rooms,start,move,previewMeld,meldCandidates}=require('../server');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
const lan=JSON.parse(html.match(/<script id="mf-lan-src" type="application\/json">([\s\S]*?)<\/script>/)[1]);
let num=0;
const makeRoom=()=>{const r={code:'RULE'+(++num),players:[{name:'A'},{name:'B'}],events:[],phase:'lobby',version:0};rooms.set(r.code,r);start(r,{first:0,lokis:4});r.game.drawn=true;return r;};
function putInHand(r,n,suit,side=0){const g=r.game;for(const pack of [g.deck,...g.hands,g.discard]){const idx=pack.findIndex(c=>!c.joker&&c.n===n&&c.suit===suit);if(idx>=0){const card=pack.splice(idx,1)[0];g.hands[side].push(card);return card;}}throw Error('Carte introuvable '+n+' '+suit)}
const state=g=>JSON.stringify({hands:g.hands,melds:g.melds,deck:g.deck,discard:g.discard,scores:g.scores,actions:g.actions});
test('Pose individuelle et deux cartes refusées par le serveur sans modifier le plateau',()=>{
 const r=makeRoom(),g=r.game;const c=putInHand(r,2,'red');const c2=putInHand(r,3,'red');
 for(const cards of [[c.id],[c.id,c2.id]]){
  const old=state(g);
  assert.throws(()=>previewMeld(r,0,{cards}),/au moins 3 cartes/);
  assert.throws(()=>move(r,0,{type:'meld',cards}),/au moins 3 cartes/);
  assert.equal(state(g),old);
 }
 rooms.delete(r.code);
});
test('Un faux brelan / une fausse suite sont refusés sans changer les scores',()=>{
 const r=makeRoom(),g=r.game;
 const invalid=[putInHand(r,1,'red'),putInHand(r,4,'blue'),putInHand(r,8,'yellow')].map(c=>c.id);
 const before=state(g);
 assert.throws(()=>previewMeld(r,0,{cards:invalid}),/ni une suite ni un brelan/);
 assert.throws(()=>move(r,0,{type:'meld',cards:invalid}),/ni une suite ni un brelan/);
 assert.equal(state(g),before);rooms.delete(r.code);
});
test('Suite valide, complément valide et complément invalide sont distingués',()=>{
 const r=makeRoom(),g=r.game;
 const cs=[1,2,3,4,7].map(n=>putInHand(r,n,'green'));
 const three=cs.slice(0,3).map(c=>c.id);
 assert(previewMeld(r,0,{cards:three}).some(c=>c.kind==='run'));
 move(r,0,{type:'meld',cards:three});
 assert.equal(g.melds.length,1);const m=g.melds[0];assert.equal(m.cards.length,3);
 const previous=state(g);
 assert.throws(()=>previewMeld(r,0,{cards:[cs[4].id],meld:m.id}),/ne peut pas être ajoutée/);
 assert.throws(()=>move(r,0,{type:'meld',cards:[cs[4].id],meld:m.id}),/ne peut pas être ajoutée/);
 assert.equal(state(g),previous);
 assert(previewMeld(r,0,{cards:[cs[3].id],meld:m.id}).some(x=>x.length===4));
 move(r,0,{type:'meld',cards:[cs[3].id],meld:m.id});
 assert.equal(g.melds[0].cards.length,4);
 rooms.delete(r.code);
});
test('Brelan de trois couleurs valide et ajout d’une quatrième couleur valide',()=>{
 const r=makeRoom(),g=r.game;const cs=['red','blue','yellow','green'].map(s=>putInHand(r,5,s));
 assert(previewMeld(r,0,{cards:cs.slice(0,3).map(c=>c.id)}).some(x=>x.kind==='set'));
 move(r,0,{type:'meld',cards:cs.slice(0,3).map(c=>c.id)});
 assert.equal(g.melds.length,1);
 assert(previewMeld(r,0,{cards:[cs[3].id],meld:g.melds[0].id}).some(x=>x.kind==='set'));
 move(r,0,{type:'meld',cards:[cs[3].id],meld:g.melds[0].id});
 assert.equal(g.melds.length,0,'Le carré achevé doit partir à la défausse');
 assert(g.pending,'Le pouvoir du carré reste déclenché');
 rooms.delete(r.code);
});
test('Les cartes seulement sélectionnées restent dans la main, sans prévisualisation sur le terrain',()=>{
 assert.match(lan,/function updateStagePreview\(\)[\s\S]*?document\.querySelectorAll\('\.lan-stage-preview'\)/);
 const stage=lan.slice(lan.indexOf('function updateStagePreview(){'),lan.indexOf('function enableDrag(){'));
 assert.doesNotMatch(stage,/\.prepend\(preview\)/);
 assert.match(lan,/function refreshPoseEligibility\(/);
 assert.match(lan,/button\.disabled=!poseCheckAllowed/);
 assert.match(lan,/if\(!meld&&unique\.length<3\)throw Error/);
});
