const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const raw=/\<script id="mf-lan-src" type="application\/json">([\s\S]*?)\<\/script>/.exec(src);
assert.ok(raw,'LAN embarqué');
const lan=JSON.parse(raw[1]);
const block=/\/\* CORRECTIF PLATEAU LAN[\s\S]*?(?=\<\/style>)/.exec(lan)?.[0];
assert.ok(block,'correctif CSS');
test('Les terrains joueur et adversaire partagent le même centrage (aucun style propre à PC1 ou PC2)',()=>{
 assert.match(block,/#game \.mf-play-zones \.mf-meld-band\s*\{/);
 assert.match(block,/justify-content:safe center!important/);
 assert.match(block,/align-content:safe center!important/);
 assert.doesNotMatch(block,/#(?:enemyMelds|myMelds)\b/);
});
test('Le débordement continue de défiler depuis son origine sans masquer des combinaisons',()=>{
 assert.match(block,/overflow-y:auto!important/);
 assert.match(block,/overflow-x:hidden!important/);
 assert.match(block,/\.lan-meld-row\s*\{[\s\S]*?overflow-x:auto/);
});
