'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const parseEmbedded=name=>{
 const match=html.match(new RegExp('<script id="mf-'+name+'-src" type="application/json">([\\s\\S]*?)<\\/script>'));
 assert.ok(match,'Embedded engine '+name+' found');return JSON.parse(match[1]);
};
const solo=parseEmbedded('solo'),lan=parseEmbedded('lan');
test('Mode Tablette selectable sous Jouabilité dans les 2 modes',()=>{
 assert.match(solo,/data-pref="tabletMode"/);
 assert.match(solo,/mf-gameplay-settings/);
 assert.match(lan,/data-shared-pref="\$\{key\}"/); // unified control builder
 assert.match(lan,/section\('gameplay','📱 Performance/);
 assert.match(lan,/return display\+sizes\+colors\+sounds\+music\+tablet\+gameplay/);
});
test('Solo et LAN partagent la même préférence persistée',()=>{
 assert.match(solo,/tabletMode:false,sound:true/);
 assert.match(lan,/tabletMode:false,sound:true/);
 assert.match(solo,/document\.body\.dataset\.mfTablet=prefs\.tabletMode/);
 assert.match(lan,/document\.body\.dataset\.mfTablet=src\.tabletMode/);
 assert.match(lan,/saveSharedFromLAN\(\{\[key\]:val\}\)/);
});
test('Mode Tablette ne remplace pas les réglages personnalisés des animations',()=>{
 assert.match(solo,/const prefersNoMotion=\(\)=>window\.matchMedia/); // conserve le rebond des cartes
 assert.doesNotMatch(solo,/prefs\.motion=['"]off['"]/);
 assert.match(lan,/const enabledMotion=\(\)=>document\.body\.dataset\.mfTablet!==['"]on['"]/);
 assert.match(solo,/body\[data-mf-tablet="on"\]/);
 assert.match(lan,/body\[data-mf-tablet="on"\]/);
});
test('Polling réduit et requêtes non chevauchantes en LAN, sans bloquer les coups',()=>{
 assert.match(lan,/let mfPollPending=false,mfWaitBusy=false/);
 assert.match(lan,/async function mfWaitRoom\(\)/);
 assert.match(lan,/if\(mfPollPending\|\|document\.hidden\|\|!session\)return/);
 assert.match(lan,/setInterval\(mfPollRoom,/);
 assert.match(lan,/async function act\(route,args\)/);
});
test('Illustrations réutilisées avec URL Blob en mode Tablette',()=>{
 for(const code of [solo,lan]){
  assert.match(code,/URL\.createObjectURL\(new Blob\(\[bytes\]/);
  assert.match(code,/URL\.revokeObjectURL\(url\)/);
 }
});
