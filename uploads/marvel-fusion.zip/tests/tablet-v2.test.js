'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const embedded=(n)=>JSON.parse(html.match(new RegExp(`<script id="mf-${n}-src" type="application/json">([\\s\\S]*?)<\\/script>`))[1]);
const solo=embedded('solo'),lan=embedded('lan');
const {server}=require('../server');
const req=(base,route,data)=>fetch(base+'/api/'+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).then(async res=>({ok:res.ok,status:res.status,data:await res.json()}));
test('Tablette 2.0 : mouvements fluides avec requestAnimationFrame et annulation au lâcher',()=>{
 assert.match(solo,/if\(!held\.moveRaf\)held\.moveRaf=requestAnimationFrame/);
 assert.match(solo,/if\(wasDragging\.moveRaf\)cancelAnimationFrame/);
 assert.match(lan,/if\(!d\.moveRaf\)d\.moveRaf=requestAnimationFrame/);
 assert.match(lan,/if\(d\.moveRaf\)cancelAnimationFrame/);
 assert.match(lan,/translate3d\(/);
});
test('Tablette 2.0 : animations de cartes préservées et effets lourds allégés',()=>{
 assert.match(solo,/animation-duration:\.22s!important/);
 assert.match(lan,/transition-duration:\.16s!important/);
 assert.doesNotMatch(solo,/animation-duration:\.10s!important;animation-iteration-count:1!important;transition-duration:\.10s!important/);
 // Le clignotement des cartes sur Safari a été corrigé en retirant content-visibility:auto.
 assert.doesNotMatch(lan,/content-visibility:auto/);
});
test('Tablette 2.0 : DOM du réseau et médias conservés si identiques',()=>{
 assert.match(lan,/const mfTabletHTMLCache=new Map\(\)/);
 assert.match(lan,/mfSetHTML\('enemyMelds'/);
 assert.match(lan,/mfSetHTML\('myHand'/);
 assert.match(lan,/mfTabletHTMLCache\.delete\('myHand'\)/);
 assert.match(lan,/mfTabletHTMLCache\.get\('discardTop'\)/);
});
test('Mode Tablette réseau : attente suspendue et repli en polling',()=>{
 assert.match(lan,/async function mfWaitRoom\(\)/);
 assert.match(lan,/fetch\('\/api\/wait'/);
 assert.match(lan,/mfWaitUnsupported=true/);
 assert.match(lan,/if\(mfPollPending\|\|document\.hidden\|\|!session\)return/);
});
test('Server /api/wait : réveil instantané, timeout et authentification', {timeout:9000},async t=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const base='http://127.0.0.1:'+server.address().port;
 t.after(()=>new Promise(r=>server.close(r)));
 const a=await req(base,'create',{name:'Joueur A'});assert.equal(a.status,200);
 const b=await req(base,'join',{code:a.data.code,name:'Joueur B'});assert.equal(b.status,200);
 const sesA={...a.data},sesB={...b.data};
 const stateA=(await req(base,'state',sesA)).data;
 const stateB=(await req(base,'state',sesB)).data;
 assert.equal(stateA.version,stateB.version);
 const denied=await req(base,'wait',{...sesA,token:'faux',version:stateA.version});assert.equal(denied.status,400);
 let resolved=false;
 const waiting=req(base,'wait',{...sesB,version:stateB.version}).then(res=>{resolved=true;return res});
 await new Promise(r=>setTimeout(r,100));assert.equal(resolved,false,'pas de réponse sans changement');
 const started=await req(base,'start',{...sesA,first:0,lokis:4});assert.equal(started.status,200);
 const changed=await Promise.race([waiting,new Promise((_,rej)=>setTimeout(()=>rej(Error('long poll trop lent')),2500))]);
 assert.equal(changed.status,200);assert.equal(changed.data.phase,'playing');
 const draw=await req(base,'move',{...sesA,type:'draw',source:'deck'});assert.equal(draw.status,200);
 const next=await req(base,'wait',{...sesB,version:changed.data.version});assert.equal(next.status,200);
 assert.equal(next.data.game.drawn,true);
});
