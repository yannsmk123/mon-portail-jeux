'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const embedded=n=>JSON.parse(html.match(new RegExp(`<script id="mf-${n}-src" type="application/json">([\\s\\S]*?)<\\/script>`))[1]);
const solo=embedded('solo'),lan=embedded('lan');
test('Tablette 3 : conservation des cartes et recherche indexée dans les deux modes',()=>{
 for(const src of [solo,lan]){
  assert.match(src,/const keyedNodes=new Map\(\)/);
  assert.match(src,/const identity=child\.tagName\+'\|'\+key/);
  assert.match(src,/const pool=keyedNodes\.get\(upcoming\.tagName\+'\|'\+key\)/);
  assert.match(src,/mfSyncStable\(matched,upcoming\)/);
 }
});
test('Tablette 3 : le lecteur musical solo est conservé entre rendus identiques',()=>{
 assert.match(solo,/mfLastAudioToolbarMarkup!==markup\|\|!headerPlayer\.firstElementChild/);
 assert.match(solo,/mfLastAudioToolbarMarkup=markup/);
 assert.match(solo,/function mfAudioPlayerHTML\(\)/);
});
test('Tablette 3 : aucun recalcul de taille du LAN pour un état inchangé',()=>{
 assert.match(lan,/if\(signature===mfLastAppliedNetworkScale\)return/);
 assert.match(lan,/if\(document\.documentElement\.style\.getPropertyValue\('--lan-hand-card-width'\)!==nextWidth\)/);
});
test('Tablette 3 : coordonnées réseau mesurées seulement avant une action animée',()=>{
 assert.match(lan,/const hasNewActions=!!previous\?\.game&&lastSeq>=0&&latestSeq>lastSeq/);
 assert.match(lan,/const snap=hasNewActions\?snapshotOld\(previous\):null/);
 assert.match(lan,/afterRender\(j,previous,snap\)/);
 assert.match(lan,/mfSetHTML\('hint',g\.pending\?/);
});
