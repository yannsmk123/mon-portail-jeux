const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const file=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const script=(id)=>{const re=new RegExp('<script id="mf-'+id+'-src" type="application/json">([\\s\\S]*?)<\\/script>');const m=file.match(re);assert.ok(m,id+' doit être embarqué');return JSON.parse(m[1]);};
const lan=script('lan');
const solo=script('solo');
const style=lan.slice(lan.indexOf('<style>'),lan.lastIndexOf('</style>'));

test('Le correctif du plateau existe uniquement en réseau',()=>{
 assert.match(style,/CORRECTIF PLATEAU LAN/);
 assert.doesNotMatch(solo,/CORRECTIF PLATEAU LAN/);
});
test('Les combinaisons sont centrées mais ne se coupent pas en cas de débordement',()=>{
 assert.match(style,/#game \.mf-play-zones \.mf-meld-band\s*\{[\s\S]*?align-content:safe center!important/);
 assert.match(style,/#game \.mf-play-zones \.mf-meld-band\s*\{[\s\S]*?overflow-y:auto!important/);
});
test('Les combinaisons longues restent contenues dans le terrain et accessibles',()=>{
 assert.match(style,/#game \.mf-play-zones \.mf-meld-band \.lan-meld\s*\{[\s\S]*?max-width:100%/);
 assert.match(style,/#game \.mf-play-zones \.lan-meld-row\s*\{[\s\S]*?overflow-x:auto/);
});
test('La première combinaison avec ses boutons dispose de sa place sur ordinateur et mobile',()=>{
 assert.match(style,/#game \.mf-layout\{min-height:740px\}/);
 assert.match(style,/#game \.mf-play-zones > \.mf-table-group\{min-height:195px\}/);
});
test('La référence solo originale est inchangée',()=>{
 assert.equal(crypto.createHash('sha256').update(solo).digest('hex'),'c765fec40e80828ab4669cd6a463dc8a9d432a316d0dde2042365d7e3027b354');
});
