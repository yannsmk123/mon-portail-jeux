'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {rooms,start,move,view}=require('../server');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const lan=JSON.parse(html.match(/<script id="mf-lan-src" type="application\/json">([\s\S]*?)<\/script>/)[1]);
let sequence=0;
function makeRoom(){let code='FEEL'+ ++sequence;let r={code,players:[{name:'Joueur A'},{name:'Joueur B'}],events:[],phase:'lobby',version:0};rooms.set(code,r);start(r,{lokis:4,first:0});return r;}
function inventory(g){let all=[...g.deck,...g.discard,...g.hands.flat(),...g.melds.flatMap(x=>x.cards)];assert.equal(all.length,84);assert.equal(new Set(all.map(c=>c.id)).size,84);}
test('Halo solo conservé et piloté par la possibilité de piocher du joueur actif',()=>{
 assert(lan.includes('animation:mfDrawHalo 2s ease-in-out infinite'));
 assert(lan.includes("$('drawDeck').classList.toggle('mf-draw-ready',!$('drawDeck').disabled)"));
});
test('Tri de main indépendant du tour, mais pose et défausse restent soumises au tour',()=>{
 assert.match(lan,/function canSortCards\(\)\{return !!\(view\?\.phase==='playing'&&view\.game&&liveHandCards\(\)\.length\)\}/);
 assert(lan.includes('function canDropCards(){return canDragThisTurn()&&!busy&&!!view.game.drawn}'));
 assert(lan.includes('if(pointerDrag?.active){deferredView=j;return;}'));
 assert(lan.includes("if(deferredView){const next=deferredView;deferredView=null;render(next);}"));
 assert(lan.includes('lan-passive-power'));
});
test('Dernière carte défaussée : huit nouvelles cartes et événement privé',()=>{
 const r=makeRoom(),g=r.game;g.drawn=true;
 while(g.hands[0].length>1)g.deck.push(g.hands[0].pop());
 move(r,0,{type:'discard',cards:[g.hands[0][0].id]});
 assert.equal(g.hands[0].length,8);assert.equal(g.current,1);
 const refills=g.actions.filter(a=>a.kind==='refill');assert.equal(refills.length,1);
 assert.deepEqual({by:refills[0].by,count:refills[0].count},{by:0,count:8});
 assert(!('cards' in refills[0]),'aucune carte privée dans l’événement commun');
 assert.equal(view(r,1).game.hands[0],8);inventory(g);rooms.delete(r.code);
});
test('Défausse forcée et vol du dernier exemplaire déclenchent aussi 8 cartes',()=>{
 for(const kind of ['enemy-discard','steal']){
  const r=makeRoom(),g=r.game;g.drawn=true;
  while(g.hands[1].length>1)g.deck.push(g.hands[1].pop());
  g.pending={by:0,stage:kind,number:kind==='steal'?6:3,remaining:1};
  move(r,0,{type:'power-choice',choice:'pick',card:g.hands[1][0].id});
  assert.equal(g.hands[1].length,8,kind);
  const refill=g.actions.find(a=>a.kind==='refill');assert.equal(refill.by,1);assert.equal(refill.count,8);
  assert.equal(view(r,0).game.hands[1],8);inventory(g);rooms.delete(r.code);
 }
});
test('Lorsque le paquet est insuffisant, le moteur renouvelle autant que possible sans dupliquer',()=>{
 const r=makeRoom(),g=r.game;g.drawn=true;
 // Stock réaliste épuisé : déplacer le stock dans une combinaison non jouée.
 const stock=g.deck.splice(0);g.melds.push({id:'simulate-stock',owner:0,kind:'run',cards:stock});
 while(g.hands[0].length>1)g.melds[0].cards.push(g.hands[0].pop());
 move(r,0,{type:'discard',cards:[g.hands[0][0].id]});
 assert.equal(g.hands[0].length,0);
 assert(r.events.some(e=>e.includes('plus de cartes disponibles')));
 assert(g.actions.some(a=>a.kind==='refill'&&a.count===0));
 inventory(g);rooms.delete(r.code);
});
